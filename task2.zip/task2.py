# Step 1: Import Required Libraries
import os
import librosa
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout

# Step 2: Feature Extraction Function
def extract_features(file_path):
    try:
        audio, sample_rate = librosa.load(file_path, res_type='kaiser_fast', duration=3)
        mfccs = librosa.feature.mfcc(y=audio, sr=sample_rate, n_mfcc=40)
        return np.mean(mfccs.T, axis=0)
    except Exception as e:
        print(f"❌ Error processing {file_path}: {e}")
        return None

# Step 3: Load and Process Dataset Recursively
emotions = {
    '01': 'neutral', '02': 'calm', '03': 'happy', '04': 'sad',
    '05': 'angry', '06': 'fearful', '07': 'disgust', '08': 'surprised'
}
features = []
labels = []

dataset_path = 'ravdess1'

if not os.path.exists(dataset_path):
    raise FileNotFoundError(f"❌ Dataset path '{dataset_path}' not found.")

print("🔍 Searching for .wav files...")
for root, _, files in os.walk(dataset_path):
    for file in files:
        if file.endswith(".wav"):
            parts = file.split("-")
            if len(parts) > 2:
                emotion_code = parts[2]
                emotion = emotions.get(emotion_code)
                if emotion:
                    file_path = os.path.join(root, file)
                    feature = extract_features(file_path)
                    if feature is not None:
                        features.append(feature)
                        labels.append(emotion)
                else:
                    print(f"⚠️ Unknown emotion code '{emotion_code}' in file {file}")
            else:
                print(f"⚠️ Filename format issue in {file}")

print(f"✅ Total valid files processed: {len(features)}")

# Step 4: Prepare Dataset
X = np.array(features)
y = LabelEncoder().fit_transform(labels)
emotion_names = LabelEncoder().fit(labels).classes_

if len(X) == 0:
    raise ValueError("🚫 No valid audio samples extracted. Please check dataset structure and contents.")

# Visualize label distribution
plt.figure(figsize=(10, 6))
sns.countplot(x=labels, order=emotion_names)
plt.title("Emotion Distribution in Dataset")
plt.ylabel("Count")
plt.xlabel("Emotions")
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# Step 5: Split Dataset
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Step 6: Build LSTM Model
model = Sequential([
    tf.keras.layers.Reshape((40, 1), input_shape=(40,)),
    LSTM(128),
    Dropout(0.3),
    Dense(64, activation='relu'),
    Dense(len(np.unique(y)), activation='softmax')
])

model.compile(loss='sparse_categorical_crossentropy', optimizer='adam', metrics=['accuracy'])

# Step 7: Train Model
history = model.fit(X_train, y_train, epochs=50, batch_size=32, validation_data=(X_test, y_test))

# Step 8: Plot Training History
plt.figure(figsize=(12, 6))
plt.plot(history.history['accuracy'], label='Train Accuracy')
plt.plot(history.history['val_accuracy'], label='Validation Accuracy')
plt.title("Model Accuracy Over Epochs")
plt.xlabel("Epochs")
plt.ylabel("Accuracy")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()

plt.figure(figsize=(12, 6))
plt.plot(history.history['loss'], label='Train Loss')
plt.plot(history.history['val_loss'], label='Validation Loss')
plt.title("Model Loss Over Epochs")
plt.xlabel("Epochs")
plt.ylabel("Loss")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()

# Step 9: Evaluate Model
test_loss, test_accuracy = model.evaluate(X_test, y_test)
print("🎯 Test Accuracy:", test_accuracy)

# Step 10: Confusion Matrix and Classification Report
y_pred = np.argmax(model.predict(X_test), axis=1)

cm = confusion_matrix(y_test, y_pred)
plt.figure(figsize=(10, 8))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=emotion_names, yticklabels=emotion_names)
plt.title("Confusion Matrix")
plt.xlabel("Predicted")
plt.ylabel("True")
plt.tight_layout()
plt.show()

print("\n📊 Classification Report:")
print(classification_report(y_test, y_pred, target_names=emotion_names))
